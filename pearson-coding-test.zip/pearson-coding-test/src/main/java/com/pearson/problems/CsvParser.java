package com.pearson.problems;

import java.util.ArrayList;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.pearson.problems.utils.ScannerUtil;
import com.pearson.problems.utils.StringConstants;

/**
 * This class prints  each value being an integer or a string on a separate line from the given CSV input.
 * 
 * @author manikanta_komarapu
 * @version 1.0
 */
public class CsvParser {
	
	private static final Logger LOGGER = Logger.getLogger(CsvParser.class.getName());
	
	/**
	 * This method is used to parse the given CSV input and prints each value on separate line.
	 * 
	 * @param input
	 * @return String each value separated by /n
	 */
	public String parseCsv(String input) {
		//To save weather the double quote has been 
		//entered or not with initial value false
		String csvOutput = StringConstants.EMPTY_STRING;
		boolean quoteCheck=false;
		List<String> csvList=new ArrayList<String>();
		StringBuilder buff = new StringBuilder(); 
		for(int i=0;i<input.length(); i++){
			//if char is quote put it on string buff 
			//and make quote check true
			char token = input.charAt(i);
			if(token == StringConstants.DOUBLE_QUOTE) {
				quoteCheck=!quoteCheck;
				buff.append(token);
			}
			//if character is comma and is not inside quote
			//add buffered string to returning list
			else if(!quoteCheck && token == StringConstants.COMMA_DELIMITER){
				csvList.add(buff.toString());
			buff.delete(0, buff.length());
			}
			else buff.append(token);
		}
		csvList.add(buff.toString());
		if(csvList != null) {
			for(int i=0;i<csvList.size();i++) {
				csvOutput += csvList.get(i);
				csvOutput +="\n";
			}
		}
		return csvOutput;
	}
	
	public static void main(String[] args) {
		String inputCSV = StringConstants.EMPTY_STRING;
		try {
			System.out.println("Please enter the CSV String of n comma-separated values: ");
			inputCSV = ScannerUtil.readString();
			CsvParser csvParse = new CsvParser();
			System.out.println(csvParse.parseCsv(inputCSV));
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,
					"Exception occured in main method of class CsvParse where given input CSV is : "+ inputCSV, 
					e);
		}
	}

}

package com.pearson.problems.utils;

/**
 * This class is used to declare all the string constants.
 * 
 * @author manikanta_komarapu
 * 
 */
public class StringConstants {
	public static final char PLAIN_BR_OPEN = '(';
	public static final char PLAIN_BR_CLOSE = ')';
	public static final char SQUARE_BR_OPEN = '[';
	public static final char SQUARE_BR_CLOSE = ']';
	public static final char CURLY_BR_OPEN = '{';
	public static final char CURLY_BR_CLOSE = '}';
	public static final char COMMA_DELIMITER = ',';
	public static final String EMPTY_STRING = "";
	public static final String SPACE_STRING = " ";
	public static final char DOUBLE_QUOTE = '"';

	public static final String SUCCESS_MSG = "The correct time is %s.";
	public static final String FAILURE_MSG = "Look at the sun.";

}

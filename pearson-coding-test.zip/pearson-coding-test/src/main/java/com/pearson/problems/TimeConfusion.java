package com.pearson.problems;

import java.util.ArrayList;

import java.util.List;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.pearson.problems.utils.ScannerUtil;
import com.pearson.problems.utils.StringConstants;
import com.pearson.problems.utils.Time;

/**
 * This class determines the actual time from the input time values.
 * If not possible prints "Look at the sun".
 * 
 * @author manikanta_komarapu
 */
public class TimeConfusion {

	private static final Logger LOGGER = Logger.getLogger(TimeConfusion.class.getName());
	
	/**
	 * Method to process given input time strings. 
	 * Returns String value with success message or failure message.
	 * 
	 * @param totalReadings
	 * @return String of final return value
	 */
	public String processTime(String[] totalReadings) {
		String processedTime = StringConstants.EMPTY_STRING;
		
		for (int i = 0; i < totalReadings.length; i++) {
			if (totalReadings[i] == null || totalReadings[i].isEmpty()) {
				LOGGER.log(Level.SEVERE, "Entered time reading values are null or invalid where time reading value is : "
						+ totalReadings[i]);
				throw new IllegalArgumentException("Entered time reading is null or invalid");
			}
			Time time = solveConfusion(createTimeList(totalReadings[i]));
			if (time == null) {
				processedTime += StringConstants.FAILURE_MSG;
			} else {
				processedTime += String.format(StringConstants.SUCCESS_MSG, time);
			}
			processedTime += "\n";

		}
		return processedTime.trim();
	}

	/**
	 * This Method take String as input and converts string into 3 Time objects and
	 * returns it as a list
	 * 
	 * @param input
	 * @return Time objects
	 */
	private List<Time> createTimeList(String input) {
		StringTokenizer tokens = new StringTokenizer(input, " :", false);
		List<Time> timeList = new ArrayList<Time>();

		while (tokens.hasMoreTokens()) {
			int hour = Integer.parseInt(tokens.nextToken().trim());
			int minute = Integer.parseInt(tokens.nextToken().trim());
			Time time = new Time(hour, minute);
			timeList.add(time);
		}
		return timeList;
	}

	/**
	 * This methods compares each Time object among three with other two and return
	 * the Time object which is perfectly in between other Two.
	 * 
	 * @param timeList
	 * @return Time object
	 */
	private Time solveConfusion(List<Time> timeList) {
		int i = 0;
		while (i < 3) {
			// here from i two other integer k and j is created.
			// so that every time there will be three integer with value
			// 0,1,2 for comparing the Time object
			int j = i + 1;
			if (j > 2)
				j = j - 3;
			int k = i + 2;
			if (k > 2)
				k = k - 3;
			/*
			 * Here three Time object difference is compared with one another in serial
			 * order For example: say Time object A is compared to B and C is compared to A
			 * putting A in middle both comparison produces Time objects If the produced
			 * Time objects are equal then A is returned. Like wise it is done for C and D
			 * as well.
			 */
			if (timeList.get(i).compareTimeDifference(timeList.get(j))
					.equals(timeList.get(k).compareTimeDifference(timeList.get(i)))
					|| timeList.get(j).compareTimeDifference(timeList.get(i))
							.equals(timeList.get(i).compareTimeDifference(timeList.get(k)))) {
				return timeList.get(i);
			} else
				i++;
		}
		return null;

	}
	
	//Driver code
	public static void main(String[] args) {
		int number = 0;
		try {
			System.out.print("Please enter the number of time values:\n");
			String input = ScannerUtil.readString().trim();
			number = Integer.parseInt(input);
			String[] timeReadings = new String[number];
			for (int index = 0; index < number; index++) {
				timeReadings[index] = ScannerUtil.readString().trim();
			}

			TimeConfusion timeConfusion = new TimeConfusion();
			System.out.println(timeConfusion.processTime(timeReadings));

		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,
					"Exception occured in main method of class TimeConfusion where given number is :"
							+ number, e);
		}
	}

}

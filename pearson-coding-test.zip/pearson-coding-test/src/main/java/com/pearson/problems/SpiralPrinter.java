package com.pearson.problems;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.pearson.problems.utils.ScannerUtil;

/**
 * This class prints spiral form of given matrix elements from row r and column c, starting upward 
 * anti clock wise direction
 * 
 * @author manikanta_komarapu
 */
public class SpiralPrinter {
	
	private static final Logger LOGGER = Logger.getLogger(SpiralPrinter.class.getName());

	/**
	 * This method will fill the ascending numerical value to the grid.
	 * 
	 * @param row
	 * @param column
	 * @return grid
	 */
	private int[][] getGrid(int row, int column) {
	try {
		int[][] grid = new int[row][column];
		for (int k = 1, i = 0; i < row; i++)
			for (int j = 0; j < column; j++) {
				grid[i][j] = k++;
			}

		return grid;
		}catch(Exception e) {
			throw new IllegalArgumentException("Please enter correct input values");
		}
	}

	/**
	 * This method returns the list of integer values ordered in a anti spiral clockwise manner. 
	 * 
	 * @param row
	 * @param column
	 * @param xPosition
	 * @param yPosition
	 * @return list of integers
	 */
	public ArrayList<Integer> runSpiral(int row, int column, int xPosition, int yPosition) {
		ArrayList<Integer> results = new ArrayList<Integer>();
		// solving position conflict between argument and array
		xPosition--;
		yPosition--;
		// creating temp value so that actual value can't be changed
		int xTemp;
		int yTemp;
		Direction tempDirection;
		// grid creation
		int[][] grid = getGrid(row, column);
		results.add(grid[xPosition][yPosition]);
		grid[xPosition][yPosition] = -1;
		Direction currentDirection = Direction.UP;

		while (results.size() != row * column) {

			/*
			 * FIRST ATTEMPT: assigning value to temp variables and changing horizontal or
			 * vertical values according to current direction direction
			 */
			tempDirection = currentDirection;
			xTemp = xPosition;
			yTemp = yPosition;
			switch (tempDirection) {
			case UP: {
				xTemp--;
				break;
			}
			case LEFT: {
				yTemp--;
				break;
			}
			case DOWN: {
				xTemp++;
				break;
			}
			case RIGHT: {
				yTemp++;
				break;
			}
			}
			// check weather position created by value exits in current grid
			// if true change the temporary direction.
			if (checkValidPosition(xTemp, yTemp, grid)) {
				tempDirection = changeDirection(currentDirection);
			}
			/*
			 * SECONT ATTEMPT: Other wise change the current temp position to original
			 * positions. If temp x and y are not out of bound of rows and column size
			 */
			else if (xTemp < column && yTemp < row && xTemp > -1 && yTemp > -1) {
				xTemp = xPosition;
				yTemp = yPosition;
				/*
				 * Adjusting the current direction changed with straight directional value.
				 * NOTE: In this switch statement, It is adjusted that the temp position will be
				 * changed according to previous temp Direction not the current one. For
				 * example:if the temp direction is TOP then positions will be changed according
				 * to RIGHT as RIGHT LEADS to TOP
				 */
				switch (tempDirection) {
				case UP:
					yTemp++;
					break;
				case LEFT:
					xTemp--;
					break;
				case DOWN:
					yTemp--;
					break;
				case RIGHT:
					xTemp++;
					break;
				}
			}
			/*
			 * check weather position created by value exits in current grid if not then new
			 * close accessible value has to be searched
			 */
			if (!checkValidPosition(xTemp, yTemp, grid)) {
				Object[] value = getNextPosition(xPosition, yPosition, grid, tempDirection);
				xTemp = (Integer) value[0];
				yTemp = (Integer) value[1];
				tempDirection = (Direction) value[2];

			}
			/*
			 * Now, finally all the temporary value are used as actual value and the grid
			 * value of the x,y positions is added to result and that grid position is made
			 * -1.
			 */
			if (checkValidPosition(xTemp, yTemp, grid)) {
				xPosition = xTemp;
				yPosition = yTemp;
				results.add(grid[xPosition][yPosition]);
				grid[xPosition][yPosition] = -1;
				currentDirection = tempDirection;

			}
		}
		// end of loop

		return results;
	}

	/**
	 * This method is used to check the valid positions in the grid.
	 * 
	 * @param xTemp
	 * @param yTemp
	 * @param grid
	 * @return boolean true or false value
	 */
	private boolean checkValidPosition(int xTemp, int yTemp, int[][] grid) {
		try {
			return (grid[xTemp][yTemp] != -1);
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * This Method change the current direction to anti clockwise direction
	 * 
	 * @param currentDirection
	 * @return newDirection value
	 */
	private Direction changeDirection(Direction tempDirection) {
		Direction newDirection = null;
		switch (tempDirection) {
		case UP: {
			newDirection = Direction.LEFT;
			break;
		}
		case RIGHT: {
			newDirection = Direction.UP;
			break;
		}
		case LEFT: {
			newDirection = Direction.DOWN;
			break;
		}
		case DOWN: {
			newDirection = Direction.RIGHT;
			break;
		}
		}
		return newDirection;
	}

	/**
	 * If changing direction anticlockwisely or going straight is not valid then
	 * this method will jump the positions and find the most favorable anticlockwise
	 * position in the grid.
	 * 
	 * @param x
	 * @param y
	 * @param grid
	 * @param tempDirection
	 * @return An object array containing of available x and y positions with next
	 *         direction it should point
	 */
	private Object[] getNextPosition(int x, int y, int[][] grid, Direction tempDirection) {
		//
		boolean check = false;
		int xTemp, yTemp;
		int i = 0;
		while (!check) {
			if (i > 1000)
				System.exit(0);
			xTemp = x;
			yTemp = y;
			switch (tempDirection) {
			case UP: {
				xTemp--;
				break;
			}
			case LEFT: {
				yTemp--;
				break;
			}
			case DOWN: {
				xTemp++;
				break;
			}
			case RIGHT: {
				yTemp++;
				break;
			}
			}

			try {
				/*
				 * if successfully new position found then temp position are changed to actual
				 * position for value return. is set and value to end loop is also set.
				 * 
				 * Else loop re-runs.
				 * 
				 * However, if any exception happens then the current temp direction is changed.
				 * 
				 */
				if (grid[xTemp][yTemp] != -1)
					check = true;
				x = xTemp;
				y = yTemp;
			} catch (Exception e) {
				tempDirection = changeDirection(tempDirection);
			}
			i++;
		}
		Object[] rtnValue = { x, y, changeDirection(tempDirection) };
		return rtnValue;
	}

	/*
	 * Nested enum class to provide values of direction which can be used for
	 * comparisons
	 */
	public enum Direction {
		UP, DOWN, LEFT, RIGHT
	}

	//Driver Code
	public static void main(String[] args) {
		int row = 0;
		int colum = 0;
		int Xposition = 0;
		int YPosition = 0;
		System.out.println("Please enter row, colum, Xposition and YPosition for Spiral "
				+ "Followed by space or comma in between:\n");
		try {
			row = ScannerUtil.readNumber();
			colum = ScannerUtil.readNumber();
			Xposition = ScannerUtil.readNumber();
			YPosition = ScannerUtil.readNumber();

			SpiralPrinter spiral = new SpiralPrinter();
			List<Integer> spiralValues = spiral.runSpiral(row, colum, Xposition, YPosition);
			for (int i = 0; i < spiralValues.size(); i++) {
				System.out.print(spiralValues.get(i) + " ");
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,
					"Exception occured in main method of class SpiralMatrix where given row is : " + row
							+ " , colum is : " + colum + " Xposition is " + Xposition + " and YPosition is : "
							+ YPosition, e);
		}

	}

}

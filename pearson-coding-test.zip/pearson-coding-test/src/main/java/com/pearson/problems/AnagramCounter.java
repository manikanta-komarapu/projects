package com.pearson.problems;

import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.pearson.problems.utils.ScannerUtil;
import com.pearson.problems.utils.StringConstants;

/**
 * This class determine how many times the query string or an anagram of the query string appears in the parent string.
 * 
 * @author manikanta_komarapu
 */
public class AnagramCounter {

	private static final Logger LOGGER = Logger.getLogger(AnagramCounter.class.getName());

	/**
	 * This method checks number of anagrams and returns the count
	 * 
	 * @param parentString input parent string
	 * @param queryString input query string
	 * @return int count of anagrams
	 */
	public int checkAnagram(String parentString, String queryString) {
		int count = 0;
		if (!(queryString != null && parentString != null)) {
			LOGGER.log(Level.SEVERE, "Entered value for Main string is : "
					+ parentString + " and Query string is : " + queryString);
			throw new IllegalArgumentException("Main string and Query string values are null");
		}
		if (parentString.equals(StringConstants.EMPTY_STRING) || queryString.equals(StringConstants.EMPTY_STRING)) {
			LOGGER.log(Level.SEVERE, "Entered value for main string is : "
					+ parentString + " and query string is : " + queryString);
			throw new IllegalArgumentException("Main string or Query string value is empty");
		}
		int queryStringLength = queryString.length();
		int totalSubstring = parentString.length() - queryStringLength + 1;
		String sortedqueryString = sort(queryString);

		for (int i = 0; i < totalSubstring; i++) {
			String reducedparentString = parentString.substring(i, queryStringLength + i);
			if (containSameCharacters(reducedparentString, sortedqueryString))
				count++;
		}
		return count;
	}

	/**
	 * This methods compares two unsorted strings with sortedqueryString
	 * disregarding the case
	 * 
	 * @param parentString
	 * @param sortedqueryString
	 * @return boolean result of comparison
	 */
	private boolean containSameCharacters(String parentString, String sortedqueryString) {

		if (parentString.length() != sortedqueryString.length())
			return false;
		if (sort(parentString.toLowerCase()).equals(sortedqueryString.toLowerCase())) {
			return true;
		}
		return false;
	}

	/**
	 * This method sorts the characters within the Strings.
	 * 
	 * @param unsorted String
	 * @return sorted String
	 */
	private String sort(String unsorted) {
		char[] chars = unsorted.toCharArray();
		Arrays.sort(chars);
		String sorted = new String(chars);
		return sorted;
	}
	
	//Driver Code
	public static void main(String[] args) {
		String parentString = StringConstants.EMPTY_STRING;
		String queryString = StringConstants.EMPTY_STRING;
		try {
			System.out.println("Please enter the Main String:");
			parentString = ScannerUtil.readString();
			System.out.println("Please enter the Query String:");
			queryString = ScannerUtil.readString();

			AnagramCounter angaramDet = new AnagramCounter();
			System.out.println(angaramDet.checkAnagram(parentString, queryString));
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,
					"Exception occured in main method of class AnagramCounter where Main string is : " + parentString
							+ " and Query string is : " + queryString, e);
		}
	}
}

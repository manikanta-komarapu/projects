package com.pearson.problems.utils;

import java.util.Scanner;

/**
 * This utility class is to provide instance of Scanner class
 * 
 * @author manikanta_komarapu
 * 
 */
public class ScannerUtil {

	private static Scanner scanner = new Scanner(System.in);
	
	public static Scanner getScannerInstance() {
		return scanner;
	}
	
	public static String readString(){
		return scanner.nextLine();
	}
	
	public static int readNumber(){
		return scanner.nextInt();
	}
}

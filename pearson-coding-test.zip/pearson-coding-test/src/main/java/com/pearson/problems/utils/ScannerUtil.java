package com.pearson.problems.utils;

import java.util.Scanner;

/**
 * To provide instance of Scanner class
 * 
 * @author manikanta_komarapu
 * @version 1.0
 */
public class ScannerUtil {

	private static Scanner scanner = new Scanner(System.in);
	
	public static Scanner getScannerInstance() {
		return scanner;
	}
	
	public static String readString(){
		return scanner.nextLine();
	}
	
	public static int readNumber(){
		return scanner.nextInt();
	}
}

package com.pearson.problems;

import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.pearson.problems.utils.ScannerUtil;
import com.pearson.problems.utils.StringConstants;

/**
 * This class implements an application that finds an anagrams and gives count
 * of an anagram in a given parent string from query string.
 * 
 * @author manikanta_komarapu
 * @version 1.0
 */
public class AnagramDetector {

	private static final Logger LOGGER = Logger.getLogger(AnagramDetector.class.getName());

	/**
	 * This methods check number of anagram and returns the number
	 * 
	 * @param parentString
	 * @param queryString
	 * @return int number of anagrams
	 */
	public int checkAnagram(String parentString, String queryString) {
		int count = 0;
		if (!(queryString != null && parentString != null)) {
			LOGGER.log(Level.SEVERE, "input parent string or query string value is  null where parent string is : "
					+ parentString + " and query string is : " + queryString);
			throw new IllegalArgumentException("input parent string or query string value is null");
		}
		if (parentString.equals(StringConstants.EMPTY_STRING) || queryString.equals(StringConstants.EMPTY_STRING)) {
			LOGGER.log(Level.SEVERE, "input parent string or query string value is  null where parent string is : "
					+ parentString + " and query string is : " + queryString);
			throw new IllegalArgumentException("input parent string or query string value is empty");
		}
		int queryStringLength = queryString.length();
		// the number of possible substring for parentString string
		int totalSubstring = parentString.length() - queryStringLength + 1;
		String sortedqueryString = sort(queryString);

		for (int i = 0; i < totalSubstring; i++) {
			String reducedparentString = parentString.substring(i, queryStringLength + i);
			if (containSameCharacters(reducedparentString, sortedqueryString))
				count++;
		}
		return count;
	}

	/**
	 * This methods compares two unsorted strings with sortedqueryString
	 * disregarding the case
	 * 
	 * @param parentString
	 * @param sortedqueryString
	 * @return boolean result of comparison
	 */
	private boolean containSameCharacters(String parentString, String sortedqueryString) {

		if (parentString.length() != sortedqueryString.length())
			return false;
		if (sort(parentString.toLowerCase()).equals(sortedqueryString.toLowerCase())) {
			return true;
		}
		return false;
	}

	/**
	 * This method sorts the characters within the Strings.
	 * 
	 * @param unsorted String
	 * @return sorted String
	 */
	private String sort(String unsorted) {
		char[] chars = unsorted.toCharArray();
		Arrays.sort(chars);
		String sorted = new String(chars);
		return sorted;
	}
	
	//Driver Code
	public static void main(String[] args) {
		String parentString = StringConstants.EMPTY_STRING;
		String queryString = StringConstants.EMPTY_STRING;
		try {
			System.out.println("Please enter the Main String:");
			parentString = ScannerUtil.readString();
			System.out.println("Please enter the Query String:");
			queryString = ScannerUtil.readString();

			AnagramDetector angaramDet = new AnagramDetector();
			System.out.println(angaramDet.checkAnagram(parentString, queryString));
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,
					"Exception occured in main method of class AnagramDetector where parent string is : " + parentString
							+ " and query string is : " + queryString,
					e);
		}
	}
}

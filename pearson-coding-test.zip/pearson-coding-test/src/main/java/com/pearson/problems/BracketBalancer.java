package com.pearson.problems;

import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.pearson.problems.utils.ScannerUtil;
import com.pearson.problems.utils.StringConstants;

/**
 * This class is used to check String "([]{}())" contains balanced parenthesis or not.
 * Returns a string value representing 'balanced' or 'not balanced'.
 * 
 * @author manikanta_komarapu
 */
public class BracketBalancer {
	
	private static final Logger LOGGER = Logger.getLogger(BracketBalancer.class.getName());

	/**
	 * Method to check whether given character array sequence has balanced parenthesis or not. 
	 * Returns true if the given sequence has balanced parenthesis else returns false
	 * 
	 * @param input Bracket expression
	 * @return boolean based whether given parenthesisCharArray is balanced or not
	 */
	private boolean checkBracketBalance(String input) {
		// creating stack to store open brackets.
		Stack<Character> stack = new Stack<Character>();
		for (int i = 0; i < input.length(); i++) {
			char token = input.charAt(i);
			if (token == ' ')
				continue;
			if (checkOpeningBrackets(token))
				stack.push(token);
			else if (stack.empty())
				return false;
			else if ((checkbalance(token, stack.peek()))) {
				stack.pop();
			} else
				return false;
		}
		// finally check weather all the bracket is balanced
		// and stack for opening bracket is empty
		if (stack.isEmpty())
			return true;
		else
			return false;
	}

	/**
	 * This method check balance of individual bracket.
	 * 
	 * @param token input parenthesis from actual input
	 * @param peek input parenthesis from Stack
	 * @return boolean value of true or false
	 */
	private boolean checkbalance(char token, Character peek) {
		if ((token == StringConstants.PLAIN_BR_CLOSE && peek == StringConstants.PLAIN_BR_OPEN) 
				|| (token == StringConstants.CURLY_BR_CLOSE && peek == StringConstants.CURLY_BR_OPEN) 
				|| (token == StringConstants.SQUARE_BR_CLOSE && peek == StringConstants.SQUARE_BR_OPEN)) {
			return true;
		}
		return false;
	}

	/**
	 * This method checks weather the bracket is opening or closing
	 * 
	 * @param value character parenthesis
	 * @return boolean value of true or false
	 */
	private boolean checkOpeningBrackets(char value) {
		if (value == StringConstants.CURLY_BR_OPEN  || value == StringConstants.PLAIN_BR_OPEN 
				|| value == StringConstants.SQUARE_BR_OPEN) {
			return true;
		}
		return false;
	}
	
	/**
	 * This method is to process the balanced bracket string.
	 * Returns a string value representing 'balanced' or 'not balanced'.
	 * throw <code>IllegalArgumentException</code> if input string is null. 
	 * 
	 * @param parenthesis string
	 * @return string of "balanced" or "not balanced" 
	 */
	public String processBalancedBrackets(String parenthesis) {
		if (parenthesis != null) {
			if (checkBracketBalance(parenthesis)) {
				return "balanced";
			} else {
				return "not balanced";
			}
		} else {
			LOGGER.log(Level.SEVERE, "Entered parenthesis string is : "
					+ parenthesis );
			throw new IllegalArgumentException("Entered parenthesis string value is null");
		}
	}
	
	public static void main(String[] args) {
		String parenthesis = StringConstants.EMPTY_STRING;
		try {
			System.out.println("Please enter the bracket expression");
			parenthesis = ScannerUtil.readString();
			BracketBalancer balanceBracket = new BracketBalancer();
			System.out.println(balanceBracket.processBalancedBrackets(parenthesis));
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE,
					"Exception occured in main method of class ParenthesisProcessor where given parenthesis are : "
							+ parenthesis, e);
		}
	}
}

package com.pearson.problems;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This Test class will execute AnagramCounter with all the possible scenario's of input values.
 * 
 * @author manikanta_komarapu
 */
public class AnagramCounterTest {

	@Before
	public void setUp() throws Exception {
		//To setup anything before executing each test.
	}

	@After
	public void tearDown() throws Exception {
		//This will execute after each test case is executed
	}
	
	//This method returns the instance of the testable class
	private AnagramCounter getAnagramDetectionInstance() {
		return new AnagramCounter();
	}

	@Test
	public void testAssertEqualsWithMessageCase1() {
		AnagramCounter anagramDetector = getAnagramDetectionInstance();
		assertEquals("testAssertEqualsWithMessageCase1", 4, anagramDetector.checkAnagram("AdnBndAndBdaBn", "dAn"));
	}

	@Test
	public void testAssertEqualsWithMessageCase2() {
		AnagramCounter anagramDetector = getAnagramDetectionInstance();
		assertEquals("testAssertEqualsWithMessageCase2", 2, anagramDetector.checkAnagram("AbrAcadAbRa", "cAda"));
	}
	
	//Below are the cases where we will get IllegalArgumentException.
	@Test(expected = IllegalArgumentException.class)
	public void testAssertEqualsWithNullMessage() {
		AnagramCounter anagramDetector = getAnagramDetectionInstance();
		assertEquals("testAssertEqualsWithNullMessage", anagramDetector.checkAnagram(null, null));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAssertEqualsWithEmptyMessage() {
		AnagramCounter anagramDetector = getAnagramDetectionInstance();
		assertEquals("testAssertEqualsWithEmptyMessage", anagramDetector.checkAnagram("", ""));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAssertEqualsWithNullQueryString() {
		AnagramCounter anagramDetector = getAnagramDetectionInstance();
		assertEquals("testAssertEqualsWithNullQueryString", anagramDetector.checkAnagram("AbrAcadAbRa", null));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAssertEqualsWithEmptyQueryString() {
		AnagramCounter anagramDetector = getAnagramDetectionInstance();
		assertEquals("testAssertEqualsWithEmptyQueryString", anagramDetector.checkAnagram("AbrAcadAbRa", ""));
	}

}
package com.pearson.problems;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class CsvParserTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	private CsvParser getCsvParserInstance() {
		return new CsvParser();
	}

	@Test
	public void testAssertEqualsWithMessageCase1() {
		CsvParser csvParser = getCsvParserInstance();
		String expectedOutput = 2+"\n"+6+"\n"+3+"\n"+2+"\n"+5+"\n";
		assertEquals("testAssertEqualsWithMessageCase1", expectedOutput, csvParser.parseCsv("2,6,3,2,5"));
	}

	@Test
	public void testAssertEqualsWithMessageCase2() {
		CsvParser csvParser = getCsvParserInstance();
		String expectedOutput = "\"pears\""+"\n"+"\"apples\""+"\n"+"\"walnuts\""+"\n"+"\"grapes\""+"\n"+"\"cheese,cake\""+"\n";
		assertEquals("testAssertEqualsWithMessageCase2", expectedOutput, csvParser.parseCsv("\"pears\""+","+"\"apples\""+","+"\"walnuts\""+","+"\"grapes\""+","+"\"cheese,cake\""));
	}

}

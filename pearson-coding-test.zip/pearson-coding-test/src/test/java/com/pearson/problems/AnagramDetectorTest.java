package com.pearson.problems;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AnagramDetectorTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	private AnagramDetector getAnagramDetectionInstance() {
		return new AnagramDetector();
	}

	@Test
	public void testAssertEqualsWithMessageCase1() {
		AnagramDetector anagramDetector = getAnagramDetectionInstance();
		assertEquals("testAssertEqualsWithMessageCase1", 4, anagramDetector.checkAnagram("AdnBndAndBdaBn", "dAn"));
	}

	@Test
	public void testAssertEqualsWithMessageCase2() {
		AnagramDetector anagramDetector = getAnagramDetectionInstance();
		assertEquals("testAssertEqualsWithMessageCase2", 2, anagramDetector.checkAnagram("AbrAcadAbRa", "cAda"));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAssertEqualsWithNullMessage() {
		AnagramDetector anagramDetector = getAnagramDetectionInstance();
		assertEquals("testAssertEqualsWithNullMessage", anagramDetector.checkAnagram(null, null));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAssertEqualsWithEmptyMessage() {
		AnagramDetector anagramDetector = getAnagramDetectionInstance();
		assertEquals("testAssertEqualsWithEmptyMessage", anagramDetector.checkAnagram("", ""));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAssertEqualsWithNullQueryString() {
		AnagramDetector anagramDetector = getAnagramDetectionInstance();
		assertEquals("testAssertEqualsWithNullQueryString", anagramDetector.checkAnagram("AbrAcadAbRa", null));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAssertEqualsWithEmptyQueryString() {
		AnagramDetector anagramDetector = getAnagramDetectionInstance();
		assertEquals("testAssertEqualsWithEmptyQueryString", anagramDetector.checkAnagram("AbrAcadAbRa", ""));
	}

}
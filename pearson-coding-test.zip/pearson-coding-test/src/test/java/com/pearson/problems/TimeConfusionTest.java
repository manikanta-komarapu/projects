package com.pearson.problems;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TimeConfusionTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	private TimeConfusion getTimeConfusionInstance() {
		return new TimeConfusion();
	}

	@Test
	public void testAssertEqualsWithMessageCase1() {
		TimeConfusion timeConfusion = getTimeConfusionInstance();
		String[] cases = { "5:00 12:00 10:00" };
		assertEquals("testAssertEqualsWithMessageCase1", "The correct time is 5:00.", timeConfusion.processTime(cases));
	}

	@Test
	public void testAssertEqualsWithMessageCase2() {
		TimeConfusion timeConfusion = getTimeConfusionInstance();
		String[] cases = { "11:59 12:30 1:01" };
		assertEquals("testAssertEqualsWithMessageCase2", "The correct time is 12:30.",
				timeConfusion.processTime(cases));
	}

	@Test
	public void testAssertEqualsWithMessageCase3() {
		TimeConfusion timeConfusion = getTimeConfusionInstance();
		String[] cases = { "12:00 4:00 8:00" };
		assertEquals("testAssertEqualsWithMessageCase3", "The correct time is 12:00.", timeConfusion.processTime(cases));
	}
	
	@Test
	public void testAssertEqualsWithMessageCase4() {
		TimeConfusion timeConfusion = getTimeConfusionInstance();
		String[] cases = { "12:00 6:00 4:00" };
		assertEquals("testAssertEqualsWithMessageCase3", "Look at the sun.", timeConfusion.processTime(cases));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAssertEqualsWithEmptyMessage() {
		TimeConfusion timeConfusion = getTimeConfusionInstance();
		String[] cases = { "" };
		assertEquals("testAssertEqualsWithEmptyMessage", "Look at the sun.", timeConfusion.processTime(cases));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAssertEqualsWithNullMessage() {
		TimeConfusion timeConfusion = getTimeConfusionInstance();
		String[] cases = { null };
		assertEquals("testAssertEqualsWithNullMessage", "Look at the sun.", timeConfusion.processTime(cases));
	}
}
package com.pearson.problems;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class BracketBalancerTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	private BracketBalancer getBracketBalancerInstance() {
		return new BracketBalancer();
	}

	@Test
	public void testAssertEqualsWithMessageCase1() {
		BracketBalancer bracketBalancer = getBracketBalancerInstance();
		assertEquals("testAssertEqualsWithMessageCase1", "balanced",
				bracketBalancer.processBalancedBrackets("()[]{}(([])){[()][]}"));
	}

	@Test
	public void testAssertEqualsWithMessageCase2() {
		BracketBalancer bracketBalancer = getBracketBalancerInstance();
		assertEquals("testAssertEqualsWithMessageCase2", "not balanced",
				bracketBalancer.processBalancedBrackets("())[]{}"));
	}

	@Test
	public void testAssertEqualsWithMessageCase3() {
		BracketBalancer bracketBalancer = getBracketBalancerInstance();
		assertEquals("testAssertEqualsWithMessageCase3", "not balanced",
				bracketBalancer.processBalancedBrackets("[(])"));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAssertEqualsWithNullMessage() {
		BracketBalancer bracketBalancer = getBracketBalancerInstance();
		assertEquals("testAssertEqualsWithNullMessage", bracketBalancer.processBalancedBrackets(null));
	}

	@Test
	public void testAssertEqualsWithEmptyMessage() {
		BracketBalancer bracketBalancer = getBracketBalancerInstance();
		assertEquals("testAssertEqualsWithEmptyMessage", "balanced", bracketBalancer.processBalancedBrackets(""));
	}

	@Test
	public void testAssertEqualsWithLargeMessage() {
		BracketBalancer bracketBalancer = getBracketBalancerInstance();
		assertEquals("testAssertEqualsWithLargeMessage", "balanced", bracketBalancer.processBalancedBrackets(
				"()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}"));
	}
}
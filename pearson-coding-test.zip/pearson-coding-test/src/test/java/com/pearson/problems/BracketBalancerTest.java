package com.pearson.problems;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This Test class will execute BracketBalancer with all the possible scenario's of input values.
 * 
 * @author manikanta_komarapu
 */
public class BracketBalancerTest {

	@Before
	public void setUp() throws Exception {
		//To setup anything before executing each test.
	}

	@After
	public void tearDown() throws Exception {
		//This will execute after each test case is executed
	}
	
	//This method returns the instance of the testable class
	private BracketBalancer getBracketBalancerInstance() {
		return new BracketBalancer();
	}

	@Test
	public void testAssertEqualsWithMessageCase1() {
		BracketBalancer bracketBalancer = getBracketBalancerInstance();
		assertEquals("testAssertEqualsWithMessageCase1", "balanced",
				bracketBalancer.processBalancedBrackets("()[]{}(([])){[()][]}"));
	}

	@Test
	public void testAssertEqualsWithMessageCase2() {
		BracketBalancer bracketBalancer = getBracketBalancerInstance();
		assertEquals("testAssertEqualsWithMessageCase2", "not balanced",
				bracketBalancer.processBalancedBrackets("())[]{}"));
	}

	@Test
	public void testAssertEqualsWithMessageCase3() {
		BracketBalancer bracketBalancer = getBracketBalancerInstance();
		assertEquals("testAssertEqualsWithMessageCase3", "not balanced",
				bracketBalancer.processBalancedBrackets("[(])"));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAssertEqualsWithNullMessage() {
		BracketBalancer bracketBalancer = getBracketBalancerInstance();
		assertEquals("testAssertEqualsWithNullMessage", bracketBalancer.processBalancedBrackets(null));
	}

	@Test
	public void testAssertEqualsWithEmptyMessage() {
		BracketBalancer bracketBalancer = getBracketBalancerInstance();
		assertEquals("testAssertEqualsWithEmptyMessage", "balanced", bracketBalancer.processBalancedBrackets(""));
	}

	@Test
	public void testAssertEqualsWithLargeMessage() {
		BracketBalancer bracketBalancer = getBracketBalancerInstance();
		assertEquals("testAssertEqualsWithLargeMessage", "balanced", bracketBalancer.processBalancedBrackets(
				"()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}()[]{}(([])){[()][]}"));
	}
}
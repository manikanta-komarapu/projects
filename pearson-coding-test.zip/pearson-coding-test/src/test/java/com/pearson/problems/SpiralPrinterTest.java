package com.pearson.problems;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertArrayEquals;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class SpiralPrinterTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	private SpiralPrinter getSpiralPrinterInstance() {
		return new SpiralPrinter();
	}

	@Test
	public void testAssertEqualsWithMessageCase2() {
		SpiralPrinter spiral = getSpiralPrinterInstance();
		Object[] expectedSpiralForm = { 2, 1, 5, 6, 7, 3, 8, 4 };
		assertArrayEquals("testAssertEqualsWithMessageCase2", expectedSpiralForm,
				spiral.runSpiral(2, 4, 1, 2).toArray());
	}

	@Test(expected = ArrayIndexOutOfBoundsException.class)
	public void testAssertEqualsWithAllZeroMessage() {
		SpiralPrinter spiral = getSpiralPrinterInstance();
		assertEquals("testAssertEqualsWithAllZeroMessage", "", spiral.runSpiral(0, 0, 0, 0));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testAssertEqualsWithNullMessage() {
		SpiralPrinter spiral = getSpiralPrinterInstance();
		assertEquals("testAssertEqualsWithNullMessage", "", spiral.runSpiral(-1, -2, 0, 0));
	}

	@Test
	public void testAssertEqualsWithMessageCase1() {
		SpiralPrinter spiral = getSpiralPrinterInstance();
		Object[] expectedSpiralForm = { 13, 8, 7, 12, 17, 18, 19, 14, 9, 4, 3, 2, 1, 6, 11, 16, 21, 22, 23, 24, 25, 20,
				15, 10, 5 };
		assertArrayEquals("testAssertEqualsWithMessageCase1", expectedSpiralForm,
				spiral.runSpiral(5, 5, 3, 3).toArray());
	}
}
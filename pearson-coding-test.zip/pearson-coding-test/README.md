# Pre-Requisites:
Install Java preferred version 1.8, If required any specific version update java version in pom file. 
Install Maven 3.x, If required any specific repositories update the repository path in MAVEN_HOME/setting.xml file

#Project Details:
##Project Name -
pearson-coding-test
##Main Package - 
In pearson-coding-test\src\main\java com.pearson.problems
##Test Package - 
In pearson-coding-test\src\test\java com.pearson.problems 

##Project contains five assignments which are

<h2>1. Balanced Brackets</h2> It check Check whether given expression is balanced or not.

<h2>2. CSV Parsing</h2> To find n consecutive lines from a given input.

<h2>3. Anagram Detection</h2> To check how many times the query string or an anagram of the query string appears in the given string.

<h2>4. Spiral</h2> To get spiral form of given elements from given location in upward anti clock wise direction.

<h2>5. Time Confusion</h2> To get the correct time input after comparing all the input time values.

##How to run the project

<h3>Every problem contains Driver code to run each class individually</h3>

#Dependencies: 
junit 4.12 : To develop test cases we are using junit framework.

#Build: 
    Run 'mvn clean build' command, which will deletes the target folder and compiles the code.

#Test:
	Run 'mvn test' command to compile entire source code and run test cases. It will generate test case execution report in target/surefire-report folder. Where we can get complete results and details of each test case.

#Install:
	Run 'mvn clean install' command builds the code and then executes all test cases and generates artifact and copies it to repository.

#Summary: 
The project consist of programs like Balanced Brackets, CSV Parsing, Anagram Counter, Spiral Printer and Time Confusion with all the possible test scenario's.

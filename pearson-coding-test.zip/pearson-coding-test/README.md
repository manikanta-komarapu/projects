# Pre-Requisites:
Install Java preferred version 1.8, If required any specific version update java version in pom file. Install Maven 3.x, If required any specific repositories update the repository path in MAVEN_HOME/setting.xml file

#Project Details:
##Project Name -
pearson-coding-test
##Main Package - 
In pearson-coding-test\src\main\java com.pearson.problems
##Test Package - 
In pearson-coding-test\src\test\java com.pearson.problems 

#Application/main classes-
##Challenge 1 (Balanced Brackets): 
    Check whether given String of parenthesis are balanced or not. That is, every opening bracket must have a closing bracket of the same type following it.
	++Main Class :++ com\pearson\problems\BracketBalancer.java
##Challenge 2 (CSV Parsing): 
    To print each value being an integer or a string on a separate line from the given CSV input.
	++Main Class :++ com\pearson\problems\CsvParser.java
##Challenge 3 (Anagram detection): 
    Determine how many times the query string � or an anagram of the query string � appears in the parent string.
	++Main Class :++ com\pearson\problems\AnagramDetector.java
##Challenge 4 (Spiral Matrix):
    To print spiral form of given matrix elements from given location in upward anti clock wise direction.
	++Main Class :++ com\pearson\problems\SpiralPrinter.java
##Challenge 5 (Time Confusion): 
    Find correct time from given different time.
	++Main Class :++ com\pearson\problems\TimeConfusion.java

#Dependencies: 
junit 4.12 : To develop test cases we are using junit framework.

<h1>How to run project</h1>

<h3>Every problem contains Driver code to run each class individually</h3>

#Build: 
    Run 'mvn clean build' command, which will deletes the target folder and compiles the code.

#Test:
	Run 'mvn test' command to compile entire source code and run test cases. It will generate test case execution report in target/surefire-report folder. Where we can get complete results and details of each test case.

#Install:
	Run 'mvn clean install' command builds the code and then executes all test cases and generates artifact and copies it to repository.

#Summary: 
The project consist of programs (Balanced Brackets, CSV Parsing, Anagram detection, Spiral Matrix, Time Confusion) with all possible test scenarios.
